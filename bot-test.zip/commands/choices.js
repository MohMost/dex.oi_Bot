const choices = [
  {
    name: "Bulbasaur",
    value: "bulbasaur",
    },
    {
    name: "Ivysaur",
    value: "ivysaur",
    },
    {
    name: "Venusaur",
    value: "venusaur",
    },
    {
    name: "Charmander",
    value: "charmander",
    },
    {
    name: "Charmeleon",
    value: "charmeleon",
    },
    {
    name: "Charizard",
    value: "charizard",
    },
    {
    name: "Squirtle",
    value: "squirtle",
    },
    {
    name: "Wartortle",
    value: "wartortle",
    },
    {
    name: "Blastoise",
    value: "blastoise",
    },
    {
    name: "Caterpie",
    value: "caterpie",
    },
    {
    name: "Metapod",
    value: "metapod",
    },
    {
    name: "Butterfree",
    value: "butterfree",
    },
    {
    name: "Weedle",
    value: "weedle",
    },
    {
    name: "Kakuna",
    value: "kakuna",
    },
    {
    name: "Beedrill",
    value: "beedrill",
    },
    {
    name: "Pidgey",
    value: "pidgey",
    },
    {
    name: "Pidgeotto",
    value: "pidgeotto",
    },
    {
    name: "Pidgeot",
    value: "pidgeot",
    },
    {
    name: "Rattata",
    value: "rattata",
    },
    {
    name: "Raticate",
    value: "raticate",
    },
    {
    name: "Spearow",
    value: "spearow",
    },
    {
    name: "Fearow",
    value: "fearow",
    },
    {
    name: "Ekans",
    value: "ekans",
    },
    {
    name: "Arbok",
    value: "arbok",
    },
    {
    name: "Pikachu",
    value: "pikachu",
    },
    {
    name: "Raichu",
    value: "raichu",
    },
    {
    name: "Sandshrew",
    value: "sandshrew",
    },
    {
    name: "Sandslash",
    value: "sandslash",
    },
    {
    name: "Nidoran♀",
    value: "nidoran-f",
    },
    {
    name: "Nidorina",
    value: "nidorina",
    },
    {
    name: "Nidoqueen",
    value: "nidoqueen",
    },
]