import * as Dex from "pokemon-showdown";

const tackle = Dex.moves.get('Tackle');

console.log(tackle.basePower)
